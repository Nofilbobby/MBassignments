//Q1

// let name = "John Doe";
// const email = "johndoe@example.com";
// let city = "New York";
// let education = "Bachelor of Science in Computer Science";
// let occupation = "Software Engineer";
// let phoneNumber = "123-456-7890";
// let Age = "27";
// const instituteName = "New York University";

// let biodata = `
//   <h1>Biodata</h1>
//   <p>Name: ${name}</p>
//   <p>Email: ${email}</p>
//   <p>City: ${city}</p>
//   <p>Education: ${education}</p>
//   <p>Occupation: ${occupation}</p>
//   <p>Phone Number: ${phoneNumber}</p>
//   <p>Institute Name: ${instituteName}</p>
//   <p> Age: ${Age}</p>
// `;

// document.write(biodata);


//Q2
// let studentName = "John Doe";
// const mathsMarks = 80;
// const scienceMarks = 70;
// const englishMarks = 90;
// const totalMarks = 300;

// let totalObtained = mathsMarks + scienceMarks + englishMarks;
// let percentage = (totalObtained / totalMarks) * 100;

// let grade;
// if (percentage >= 80) {
//   grade = "A";
// } else if (percentage >= 60) {
//   grade = "B";
// } else if (percentage >= 40) {
//   grade = "C";
// } else {
//   grade = "F";
// }

// let markSheet = `
//   <h1>Mark Sheet</h1>
//   <p>Student Name: ${studentName}</p>
//   <table>
//     <tr>
//       <th>Subject</th>
//       <th>Marks</th>
//     </tr>
//     <tr>
//       <td>Maths</td>
//       <td>${mathsMarks}</td>
//     </tr>
//     <tr>
//       <td>Science</td>
//       <td>${scienceMarks}</td>
//     </tr>
//     <tr>
//       <td>English</td>
//       <td>${englishMarks}</td>
//     </tr>
//     <tr>
//       <th>Total</th>
//       <th>${totalObtained} / ${totalMarks}</th>
//     </tr>
//   </table>
//   <p>Percentage: ${percentage.toFixed(2)}%</p>
//   <p>Grade: ${grade}</p>
// `;

// document.write(markSheet);



//Q3
// let name = "john"
// let name = "john"
//error
// const name = "john"
// const name = "john"
//error

// function(){
//     let name = "john"
//     console.log(name);
// }
// function(){
//     const name = "john"
//     console.log(name);
// }